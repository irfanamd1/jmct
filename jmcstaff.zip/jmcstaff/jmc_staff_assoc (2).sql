-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2024 at 06:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jmc_staff_assoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `empid` varchar(20) NOT NULL,
  `prefix` varchar(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `stream` enum('Aided','Self-Finance Men','Self-Finance Women') DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `category` enum('Teaching','Non-Teaching') DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `dob` varchar(12) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`empid`, `prefix`, `name`, `qualification`, `stream`, `department`, `category`, `designation`, `dob`, `mobile`, `address`, `email`, `image`, `created_at`) VALUES
('12345', 'Mr.', 'S Irfan Ahamed', 'MCA', 'Aided', 'Computer Science', 'Teaching', 'Programmer', '07-07-2005', '1324567823', 'Trichy-1', 'cde@jmc.edu', 'uploads/Aided/Computer Science/IMG-20231207-WA0013.jpg', '2024-12-07 07:19:49'),
('JMC1234', 'Dr.', 'Balaji', 'Msc', 'Aided', 'Computer Science', 'Teaching', 'Principal', '12-12-2001', '9630258741', 'Below Sky', 'balaji123@jmc.edu', 'uploads/Aided/Computer Science/im.jpg', '2024-12-07 07:41:15'),
('JMCMNTS12345', 'Mr.', 'S. Shanal Babu', 'MCA', 'Aided', 'Computer Science', 'Teaching', 'Programmer Cum Lecturer', '07-07-1995', '8072249448', 'No 38/10, Burma Hajiyar House, Pandarinathapuram, BhimaNagar\r\nTrichy - 620001', 'ssb@jmc.edu', 'uploads/Aided/Computer Science/images.jpg', '2024-12-07 07:02:18'),
('JMCMNTS3019', 'Mr.', 'S Syed Musthafa', 'M.Sc CS', 'Self-Finance Men', 'Computer Science & IT', 'Non-Teaching', 'Web Administrator', '1975-07-10', '7094558086', '98/C N.M STORE\r\nPALAKARAI\r\nTRICHY - 620008', 'musthafa@jmc.edu', 'uploads/MUS.JPG', '2024-10-24 06:32:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`empid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
