-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2024 at 07:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jmc_staff_assoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `empid` varchar(20) NOT NULL,
  `prefix` varchar(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `stream` enum('Aided','Self-Finance Men','Self-Finance Women') DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `category` enum('Teaching','Non-Teaching') DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `dob` varchar(12) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`empid`, `prefix`, `name`, `qualification`, `stream`, `department`, `category`, `designation`, `dob`, `mobile`, `address`, `email`, `image`, `created_at`) VALUES
('124334', 'Mr.', 'Shanal Babu', 'MCA', 'Aided', 'Computer Science', 'Non-Teaching', 'Programmer Cum Lecturer', '0000-00-00', '8072249448', 'Trichy', 'ssb@jmc.edu', 'uploads/Aided/Computer Science/hand-symbol.jpg', '2024-12-03 03:28:42'),
('234344444444', 'Dr.', 'irfan', 'PhD', 'Aided', 'Tamil', 'Teaching', 'Teacher', '12-12-2002', '9632587410', 'Nagarcoil', 'hjhj@jmc.edu', 'uploads/Self-Finance Men/Physics/IMG-20231207-WA0013.jpg', '2024-12-05 06:04:05'),
('gfgyfggc', 'Dr.', 'hello', 'Msc', 'Self-Finance Men', 'Visual Communication', 'Teaching', 'Lecture', '12-15-2002', '9876543210', 'palpannai', 'hghgvhjuv@jmc.edu', 'uploads/Self-Finance Men/Visual Communication/pngtree-repair-mobile-phone-png-image_5633979.jpg', '2024-10-23 07:47:06'),
('JMCMNTS3019', 'Mr.', 'S Syed Musthafa', 'M.Sc CS', 'Self-Finance Men', 'Computer Science & IT', 'Non-Teaching', 'Web Administrator', '1975-07-10', '7094558086', '98/C N.M STORE\r\nPALAKARAI\r\nTRICHY - 620008', 'musthafa@jmc.edu', 'uploads/MUS.JPG', '2024-10-24 06:32:08'),
('sdf456666666', 'Ms.', 'Shahul', 'SSLC', 'Aided', 'Zoology', 'Non-Teaching', 'Sweeper', '0000-00-00', '9876543210', 'tvs tollgate, trichy', 'abcd@gmail.com', 'uploads/Aided/Zoology/pngtree-repair-mobile-phone-png-image_5633979.jpg', '2024-12-05 06:04:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`empid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
