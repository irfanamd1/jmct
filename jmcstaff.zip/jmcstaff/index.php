<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="shortcut icon" href="jmc.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
    <div class="container">
        <div class="admin-page">
            <a href="admin/index.php">Admin Login</a>
        </div>
        <div class="header-image">
            <img src="jmc_logos.jpg" alt="">
        </div>
        <div class="form-header">
            <h2>JMC STAFF ASSOCIATION PORTAL</h2>
            <h2>Address Book Registration Page</h2>
        </div>
        <form action="" id="form" method="POST" enctype="multipart/form-data">
            <div class="content">
                <div class="left">
                    <div class="form-input">
                        <select name="prefix" id="prefix">
                            <option value="" hidden>Title</option>
                            <option value="Dr.">Dr.</option>
                            <option value="Mr.">Mr.</option>
                            <option value="Ms.">Mrs.</option>
                            <option value="Ms.">Ms.</option>
                        </select><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input">
                        <input type="text" name="name" id="name" placeholder="Name with Initial" autocomplete="off"><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input">
                        <input type="text" name="qualification" id="qualification" placeholder="Qualification"  autocomplete="off"><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input">
                        <select name="stream" id="stream" onchange="getStream()">
                            <option value="" hidden>Stream</option>
                            <option value="Aided">Aided</option>
                            <option value="Self-Finance Men">Self-Finance Men</option>
                            <option value="Self-Finance Women">Self-Finance Women</option>
                        </select><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" id="aided" style="display: none;">
                        <select name="aided-department" id="aided-department">
                            <option value="" hidden>Department</option>
                            <option value="Arabic">Arabic</option>
                            <option value="Botany">Botany</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Commerce">Commerce</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Economics">Economics</option>
                            <option value="English">English</option>
                            <option value="French">French</option>
                            <option value="History">History</option>
                            <option value="Library">Library</option>
                            <option value="Mathematics">Mathematics</option>
                            <option value="Physical Education">Physical Education</option>
                            <option value="Physics">Physics</option>
                            <option value="Tamil">Tamil</option>
                            <option value="Urdu">Urdu</option>
                            <option value="Zoology">Zoology</option>
                        </select><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" id="sfm" style="display: none;">
                        <select name="sfm-department" id="sfm-department">
                            <option value="" hidden>Department</option>
                            <option value="Arabic">Arabic</option>
                            <option value="Biotechnology">Biotechnology</option>
                            <option value="Business Administration">Business Administration</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Commerce">Commerce</option>
                            <option value="Computer Science & IT">Computer Science & IT</option>
                            <option value="Computer Applications">Computer Applications</option>
                            <option value="English">English</option>
                            <option value="Hindi">Hindi</option>
                            <option value="History">History</option>
                            <option value="Hotel Management">Hotel Management</option>
                            <option value="Mathematics">Mathematics</option>
                            <option value="Management Studies">Management Studies</option>
                            <option value="Microbiology">Microbiology</option>
                            <option value="Physical Education">Physical Education</option>
                            <option value="Physics">Physics</option>
                            <option value="Social Work">Social Work</option>
                            <option value="Tamil">Tamil</option>
                            <option value="Visual Communication">Visual Communication</option>
                            <option value="Zoology">Zoology</option>
                        </select><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" id="sfw" style="display: none;">
                        <select name="sfw-department" id="sfw-department">
                            <option value="" hidden>Department</option>
                            <option value="Arabic">Arabic</option>
                            <option value="Biotechnology">Biotechnology</option>
                            <option value="Business Administration">Business Administration</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Commerce">Commerce</option>
                            <option value="Computer Science & IT">Computer Science & IT</option>
                            <option value="Computer Applications">Computer Applications</option>
                            <option value="English">English</option>
                            <option value="Hindi">Hindi</option>
                            <option value="Fashion Technology & Costume Designing">Fashion Technology & Costume Designing</option>
                            <option value="Mathematics">Mathematics</option>
                            <option value="Management Studies">Management Studies</option>
                            <option value="Microbiology">Microbiology</option>
                            <option value="Nutrition & Dietetics">Nutrition & Dietetics</option>
                            <option value="Physical Education">Physical Education</option>
                            <option value="Physics">Physics</option>
                            <option value="Social Work">Social Work</option>
                            <option value="Tamil">Tamil</option>
                            <option value="Urdu">Urdu</option>
                            <option value="Zoology">Zoology</option>
                        </select><br>
                        <small>Error message</small>
                    </div>
                </div>
                <div class="center">
                    <div class="form-input">
                        <select name="category" id="category" onchange="getEmail()">
                            <option value="" hidden>Category</option>
                            <option value="Teaching">Teaching</option>
                            <option value="Non-Teaching">Non-Teaching</option>
                        </select><br>
                        <small>Error message</small>
                    </div>
                    <!--<div class="form-input" id="teaching" style="display: none;">
                        <select name="teaching-designation" id="teaching-staff">
                            <option value="" hidden>Designation</option>
                            <option value="Principal, Associate Professor & Head">Principal, Associate Professor & Head</option>
                            <option value="Vice Principal, Associate Professor & Head">Vice Principal, Associate Professor & Head</option>
                            <option value="Additional Vice Principal, Associate Professor & Head">Additional Vice Principal, Associate Professor & Head</option>
                            <option value="Additional Vice Principal & Associate Professor">Additional Vice Principal & Associate Professor</option>
                            <option value="Controller of Examinations, Associate Professor & Head">Controller of Examinations, Associate Professor & Head</option>
                            <option value="Associate Professor, Bursar & Head">Associate Professor, Bursar & Head</option>
                            <option value="Deputy Controller of Examinations, Associate Professor & Head">Deputy Controller of Examinations, Associate Professor & Head</option>
                            <option value="Associate Professor & Head">Associate Professor & Head</option>
                            <option value="Associate Professor & MID">Associate Professor & MID</option>
                            <option value="Assistant Professor & Head">Assistant Professor & Head</option>
                            <option value="Assistant Professor & MID">Assistant Professor & MID</option>
                            <option value="Associate Professor">Associate Professor</option>
                            <option value="Assistant Professor">Assistant Professor</option>
                        </select><br>
						<input type="text" name="teaching-designation" id="teaching-staff" autocomplete="off" placeholder="Designation" ><br>
                        <small>Error message</small>
                    </div>-->
                    <div class="form-input">
                        <input type="text" name="designation" id="designation"  autocomplete="off" placeholder="Designation"><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input">
                        <input type="text" name="empid" id="empid" autocomplete="off" placeholder="Employee Id" maxlength="12"><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input">
                        <!--<input type="text" name="dob" id="date" placeholder="Date of Birth" onfocus="(this.type = 'date')" style="cursor: pointer;"><br>-->
						<input type="text" name="dob" id="date" placeholder="Date of Birth (DD-MM-YYYY)" maxlength="10" autocomplete="off"><br>
                        <small>Error message</small>
                    </div>

                    <div class="form-input">
                        <input type="text" name="mobile" id="mobile" autocomplete="off" placeholder="Mobile Number" maxlength="10"><br>
                        <small>Error message</small>
                    </div>
                </div>
                <div class="right">
                    <div class="form-input">
                        <textarea name="address" id="address" placeholder="Permanent Address"></textarea><br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" id="emaill">
                        <input type="text" name="email" id="email" autocomplete="off" placeholder="Email Id" disabled>
						<br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" id="teachingemaill" style="display: none;">
                        <input type="text" name="teaching-email" id="teachingemail" autocomplete="off" placeholder="Email Id (abc@jmc.edu)">
						<br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" id="nonteachingemaill" style="display: none;">
                        <input type="text" name="non-teach-email" id="nonteachingemail" autocomplete="off" placeholder="Email Id (Optional)">
						<br>
                        <small>Error message</small>
                    </div>
                    <div class="form-input" style="position: relative">
                        <div class="image-box" id="imageBox">
                            <i class="fa-solid fa-user"></i><br>
                            <p>No image selected</p>
                        </div>
                        <input type="file" name="image" id="image" accept=".jpg, .jpeg" style="text-indent: 0;">
                        <p style="color: #dc6601; font-size: 14px;">*File size must be less than 100Kb and in .jpg format</p>
						<p style="color: #dc6601; font-size: 14px;">*File Name must be your Employee Id(e.g., JMCXXXX01.jpg)</p>						
                        <small style="position: absolute; bottom: -110px;">Error message</small>
                    </div>
                </div>
            </div>
            <div class="check">
                <input type="checkbox" name="" id="check" style="cursor: pointer;" required title="Please check the box above before submitting">
                <p>I hereby declare that the above informations are correct and true</p><br>
                <small>Error message</small>
            </div>
            <div class="btn">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
    <div class="footer">
        <div class="copyright">
            <p>COPYRIGHT ©2024 Jamal Mohamed College. ALL RIGHTS RESERVED</p>
        </div>
        <div class="incharge">
            <marquee behavior="" direction="">Guided By: Dr. S. Mohamed Iliyas, S. Shanal Babu. &nbsp;&nbsp; Developers:  S. Irfan Ahamed - II MCA(Aided), P. Mohammed Fasil - II Msc.</marquee>
        </div>
    </div>



    <script src="script.js"></script>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'jmc_staff_assoc';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    $stmt = $conn->prepare("INSERT INTO registration (prefix, name, qualification, stream, department, category, designation, empid, dob, mobile, address, email, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssssss", $prefix, $name, $qualification, $stream, $department, $category, $designation, $empid, $dob, $mobile, $address, $email, $image);

    // Get form data
    $prefix = $_POST['prefix'];
    $name = $_POST['name'];
    $qualification = $_POST['qualification'];
    $stream = $_POST['stream'];
    $category = $_POST['category'];
	$designation = $_POST['designation'];
    $empid = $_POST['empid'];
    $dob = $_POST['dob'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];

   // if ($category === 'Teaching') {
	//	        $designation = $_POST['teaching-designation'];
   // } elseif ($category === 'Non-Teaching') {
     //   $designation = $_POST['non-teaching-designation'];
    // }
    
    if ($category === 'Teaching') {
        $email = $_POST['teaching-email'];
    } else {
        $email = $_POST['non-teach-email'];
    } 

    if ($stream === 'Aided') {
        $department = $_POST['aided-department'];
    } elseif ($stream === 'Self-Finance Men') {
        $department = $_POST['sfm-department'];
    } elseif ($stream === 'Self-Finance Women') {
        $department = $_POST['sfw-department'];
    }
    



    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $image = 'uploads/'.$stream.'/'.$department.'/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image);
    } else {
        $image = null;
    }

    if ($stmt->execute()) {
        echo "<script>alert('Submitted Successfully!');</script>";
    } else {
        // echo "<script>alert('Error: " . addslashes($stmt->error) . "');</script>";
        echo "<script>alert('Record already Exists');</script>";
    }


    $stmt->close();

$conn->close();
}
?>

</body>
</html>
	
