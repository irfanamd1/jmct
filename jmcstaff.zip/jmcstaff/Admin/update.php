<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'jmc_staff_assoc';

$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the employee data (from the query string, e.g., ?employee=<json_string>)
$employee = json_decode(urldecode($_GET['employee']), true);

echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const imageBox = document.getElementById("imageBox");
            imageBox.innerHTML = `<img src="' .'../'. htmlspecialchars($employee['image']) . '" alt="Selected Image">`;
        });
    </script>';

echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            let aided = document.getElementById("aided");
            let sfm = document.getElementById("sfm");
            let sfw = document.getElementById("sfw");

            if (\''.htmlspecialchars($employee['stream']).'\' === "Aided") {
                aided.style.display = "block";
                sfm.style.display = "none";
                sfw.style.display = "none";
            } else if (\''.htmlspecialchars($employee['stream']).'\' === "Self-Finance Men") {
                sfm.style.display = "block";
                aided.style.display = "none";
                sfw.style.display = "none";
            } else if (\''.htmlspecialchars($employee['stream']).'\' === "Self-Finance Women") {
                sfw.style.display = "block";
                aided.style.display = "none";
                sfm.style.display = "none";
            }
        });
    </script>';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Record</title>
    <link rel="shortcut icon" href="../jmc.png" type="image/x-icon">
    <link rel="stylesheet" href="styles1.css">
</head>
<body>
    
    <div class="container">
        <div class="header-image">
            <img src="../jmc_logos.jpg" alt="">
        </div>
        <div class="form-header">
            <h2>JMC STAFF ASSOCIATION</h2>
            <h2>Update the Record of <?= htmlspecialchars($employee['name']) ?> - <?= htmlspecialchars($employee['empid']) ?></h2>
        </div>
        <form action="" id="form" method="POST" enctype="multipart/form-data">
            <div class="content">
                <div class="left">
                    <div class="form-input">
                        <select name="prefix" id="prefix">
                            <option value="" disabled selected hidden><?= htmlspecialchars($employee['prefix']) ?></option>
                            <option value="Dr.">Dr.</option>
                            <option value="Mr.">Mr.</option>
                            <option value="Ms.">Mrs.</option>
                            <option value="Ms.">Ms.</option>
                        </select><br>
                    </div>
                    <div class="form-input">
                        <input type="text" name="name" id="name" placeholder="Name with Initial" autocomplete="off" value="<?= htmlspecialchars($employee['name']) ?>"><br>
                    </div>
                    <div class="form-input">
                        <input type="text" name="qualification" id="qualification" placeholder="Qualification" autocomplete="off" value="<?= htmlspecialchars($employee['qualification']) ?>"><br>
                    </div>
                    <div class="form-input">
                        <select name="stream" id="stream" onchange="getStream()">
                            <option value="" hidden><?= htmlspecialchars($employee['stream']) ?></option>
                            <option value="Aided" <?= $employee['stream'] === 'Aided' ? 'selected' : '' ?>>Aided</option>
                            <option value="Self-Finance Men" <?= $employee['stream'] === 'Self-Finance Men' ? 'selected' : '' ?>>Self-Finance Men</option>
                            <option value="Self-Finance Women" <?= $employee['stream'] === 'Self-Finance Women' ? 'selected' : '' ?>>Self-Finance Women</option>
                        </select><br>
                    </div>
                    <div class="form-input" id="aided" style="display: none;">
                        <select name="aided-department" id="aided-department">
                        <option value="" disabled selected hidden><?= htmlspecialchars($employee['department']) ?></option>
                        <option value="Arabic" <?= $employee['department'] === 'Arabic' ? 'selected' : '' ?>>Arabic</option>
                            <option value="Botany" <?= $employee['department'] === 'Botany' ? 'selected' : '' ?>>Botany</option>
                            <option value="Chemistry" <?= $employee['department'] === 'Chemistry' ? 'selected' : '' ?>>Chemistry</option>
                            <option value="Commerce" <?= $employee['department'] === 'Commerce' ? 'selected' : '' ?>>Commerce</option>
                            <option value="Computer Science" <?= $employee['department'] === 'Computer Science' ? 'selected' : '' ?>>Computer Science</option>
                            <option value="Economics" <?= $employee['department'] === 'Economics' ? 'selected' : '' ?>>Economics</option>
                            <option value="English" <?= $employee['department'] === 'English' ? 'selected' : '' ?>>English</option>
                            <option value="French" <?= $employee['department'] === 'French' ? 'selected' : '' ?>>French</option>
                            <option value="History" <?= $employee['department'] === 'History' ? 'selected' : '' ?>>History</option>
                            <option value="Library" <?= $employee['department'] === 'Library' ? 'selected' : '' ?>>Library</option>
                            <option value="Mathematics" <?= $employee['department'] === 'Mathematics' ? 'selected' : '' ?>>Mathematics</option>
                            <option value="Physical Education" <?= $employee['department'] === 'Physical Education' ? 'selected' : '' ?>>Physical Education</option>
                            <option value="Physics" <?= $employee['department'] === 'Physics' ? 'selected' : '' ?>>Physics</option>
                            <option value="Tamil" <?= $employee['department'] === 'Tamil' ? 'selected' : '' ?>>Tamil</option>
                            <option value="Urdu" <?= $employee['department'] === 'Urdu' ? 'selected' : '' ?>>Urdu</option>
                            <option value="Zoology" <?= $employee['department'] === 'Zoology' ? 'selected' : '' ?>>Zoology</option>
                        </select><br>
                    </div>
                    <div class="form-input" id="sfm" style="display: none;">
                        <select name="sfm-department" id="sfm-department">
                        <option value="" disabled selected hidden><?= htmlspecialchars($employee['department']) ?></option>
                        <option value="Arabic" <?= $employee['department'] === 'Arabic' ? 'selected' : '' ?>>Arabic</option>
                            <option value="Biotechnology" <?= $employee['department'] === 'Biotechnology' ? 'selected' : '' ?>>Biotechnology</option>
                            <option value="Business Administration" <?= $employee['department'] === 'Business Administration' ? 'selected' : '' ?>>Business Administration</option>
                            <option value="Chemistry" <?= $employee['department'] === 'Chemistry' ? 'selected' : '' ?>>Chemistry</option>
                            <option value="Commerce" <?= $employee['department'] === 'Commerce' ? 'selected' : '' ?>>Commerce</option>
                            <option value="Computer Science & IT" <?= $employee['department'] === 'Computer Science & IT' ? 'selected' : '' ?>>Computer Science & IT</option>
                            <option value="Computer Applications" <?= $employee['department'] === 'Computer Applications' ? 'selected' : '' ?>>Computer Applications</option>
                            <option value="English" <?= $employee['department'] === 'English' ? 'selected' : '' ?>>English</option>
                            <option value="Hindi" <?= $employee['department'] === 'Hindi' ? 'selected' : '' ?>>Hindi</option>
                            <option value="History" <?= $employee['department'] === 'History' ? 'selected' : '' ?>>History</option>
                            <option value="Hotel Management" <?= $employee['department'] === 'Hotel Management' ? 'selected' : '' ?>>Hotel Management</option>
                            <option value="Mathematics" <?= $employee['department'] === 'Mathematics' ? 'selected' : '' ?>>Mathematics</option>
                            <option value="Management Studies" <?= $employee['department'] === 'Management Studies' ? 'selected' : '' ?>>Management Studies</option>
                            <option value="Microbiology" <?= $employee['department'] === 'Microbiology' ? 'selected' : '' ?>>Microbiology</option>
                            <option value="Physical Education" <?= $employee['department'] === 'Physical Education' ? 'selected' : '' ?>>Physical Education</option>
                            <option value="Physics" <?= $employee['department'] === 'Physics' ? 'selected' : '' ?>>Physics</option>
                            <option value="Social Work" <?= $employee['department'] === 'Social Work' ? 'selected' : '' ?>>Social Work</option>
                            <option value="Tamil" <?= $employee['department'] === 'Tamil' ? 'selected' : '' ?>>Tamil</option>
                            <option value="Visual Communication" <?= $employee['department'] === 'Visual Communication' ? 'selected' : '' ?>>Visual Communication</option>
                            <option value="Zoology" <?= $employee['department'] === 'Zoology' ? 'selected' : '' ?>>Zoology</option>
                        </select><br>
                    </div>
                    <div class="form-input" id="sfw" style="display: none;">
                        <select name="sfw-department" id="sfw-department">
                        <option value="" disabled selected hidden><?= htmlspecialchars($employee['department']) ?></option>
                        <option value="Arabic" <?= $employee['department'] === 'Arabic' ? 'selected' : '' ?>>Arabic</option>
                            <option value="Biotechnology" <?= $employee['department'] === 'Biotechnology' ? 'selected' : '' ?>>Biotechnology</option>
                            <option value="Business Administration" <?= $employee['department'] === 'Business Administration' ? 'selected' : '' ?>>Business Administration</option>
                            <option value="Chemistry" <?= $employee['department'] === 'Chemistry' ? 'selected' : '' ?>>Chemistry</option>
                            <option value="Commerce" <?= $employee['department'] === 'Commerce' ? 'selected' : '' ?>>Commerce</option>
                            <option value="Computer Science & IT" <?= $employee['department'] === 'Computer Science & IT' ? 'selected' : '' ?>>Computer Science & IT</option>
                            <option value="Computer Applications" <?= $employee['department'] === 'Computer Applications' ? 'selected' : '' ?>>Computer Applications</option>
                            <option value="English" <?= $employee['department'] === 'English' ? 'selected' : '' ?>>English</option>
                            <option value="Hindi" <?= $employee['department'] === 'Hindi' ? 'selected' : '' ?>>Hindi</option>
                            <option value="Fashion Technology & Costume Designing" <?= $employee['department'] === 'Fashion Technology & Costume Designing' ? 'selected' : '' ?>>Fashion Technology & Costume Designing</option>
                            <option value="Mathematics" <?= $employee['department'] === 'Mathematics' ? 'selected' : '' ?>>Mathematics</option>
                            <option value="Management Studies" <?= $employee['department'] === 'Management Studies' ? 'selected' : '' ?>>Management Studies</option>
                            <option value="Microbiology" <?= $employee['department'] === 'Microbiology' ? 'selected' : '' ?>>Microbiology</option>
                            <option value="Nutrition & Dietetics" <?= $employee['department'] === 'Nutrition & Dietetics' ? 'selected' : '' ?>>Nutrition & Dietetics</option>
                            <option value="Physical Education" <?= $employee['department'] === 'Physical Education' ? 'selected' : '' ?>>Physical Education</option>
                            <option value="Physics" <?= $employee['department'] === 'Physics' ? 'selected' : '' ?>>Physics</option>
                            <option value="Social Work" <?= $employee['department'] === 'Social Work' ? 'selected' : '' ?>>Social Work</option>
                            <option value="Tamil" <?= $employee['department'] === 'Tamil' ? 'selected' : '' ?>>Tamil</option>
                            <option value="Urdu" <?= $employee['department'] === 'Urdu' ? 'selected' : '' ?>>Urdu</option>
                            <option value="Zoology" <?= $employee['department'] === 'Zoology' ? 'selected' : '' ?>>Zoology</option>
                        </select><br>
                    </div>
                </div>
                <div class="center">
                    <div class="form-input">
                        <select name="category" id="category">
                        <option value="" disabled selected hidden><?= htmlspecialchars($employee['stream']) ?></option>
                        <option value="Teaching" <?= $employee['category'] === 'Teaching' ? 'selected' : '' ?>>Teaching</option>
                            <option value="Non-Teaching" <?= $employee['category'] === 'Non-Teaching' ? 'selected' : '' ?>>Non-Teaching</option>
                        </select><br>
                    </div>
                    
                    <div class="form-input">
                        <input type="text" name="designation" id="designation" autocomplete="off" placeholder="Designation" value="<?= htmlspecialchars($employee['designation']) ?>"><br>
                    </div>
                    <div class="form-input">
                        <input type="text" name="empid" id="empid" autocomplete="off" placeholder="Employee Id" maxlength="12" value="<?= htmlspecialchars($employee['empid']) ?>" disabled><br>
                    </div>
                    <div class="form-input">
                        <input type="text" name="dob" id="dob" placeholder="Date of Birth (DD-MM-YYYY)" maxlength="10" value="<?= htmlspecialchars($employee['dob']) ?>"><br>
                    </div>
                    <div class="form-input">
                        <input type="text" name="mobile" id="mobile" autocomplete="off" placeholder="Mobile Number" maxlength="10" value="<?= htmlspecialchars($employee['mobile']) ?>"><br>
                    </div>
                </div>
                <div class="right">
                    <div class="form-input">
                        <textarea name="address" id="address" placeholder="Permanent Address"><?= htmlspecialchars($employee['address']) ?></textarea><br>
                    </div>
                    <div class="form-input" id="emaill">
                        <input type="text" name="email" id="email" autocomplete="off" placeholder="Email Id" value="<?= htmlspecialchars($employee['email']) ?>"><br>
                    </div>
                    <div class="form-input">
                        <div class="image-box" id="imageBox">
                            <i class="fa-solid fa-user"></i><br>
                            <p>No image selected</p>
                        </div>
                        <!-- <input type="file" name="image" id="image" accept=".jpg, .jpeg" style="text-indent: 0;">
                        <p style="color: #dc6601; font-size: 14px;">*File size must be less than 100Kb and in .jpg format</p>
                        <small style="position: absolute; bottom: -110px;">Error message</small> -->
                    </div>
                </div>
            </div>
            <div class="btn">
                <a class="button" href="dashboard.php">Back</a>
                <button class="button" type="submit">Update</button>
            </div>
        </form>
    </div>

    <script src="script1.js"></script>
    
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data
    $prefix = $_POST['prefix'] ?? $employee['prefix'];
    $name = $_POST['name'] ?? $employee['name'];
    $empid = $employee['empid'];  // Emp ID remains constant
    $qualification = $_POST['qualification'] ?? $employee['qualification'];
    $stream = $_POST['stream'] ?? $employee['stream'];
    $category = $_POST['category'] ?? $employee['category'];
    $designation = $_POST['designation'] ?? $employee['designation'];
    $dob = $_POST['dob'] ?? $employee['dob'];
    $mobile = $_POST['mobile'] ?? $employee['mobile'];
    $address = $_POST['address'] ?? $employee['address'];
    $email = $_POST['email'] ?? $employee['email'];

    // Determine the department based on the stream
    $department = $employee['department']; // Default to current department if not provided
    if ($stream === 'Aided' && isset($_POST['aided-department']) && !empty($_POST['aided-department'])) {
        $department = $_POST['aided-department'];
    } elseif ($stream === 'Self-Finance Men' && isset($_POST['sfm-department']) && !empty($_POST['sfm-department'])) {
        $department = $_POST['sfm-department'];
    } elseif ($stream === 'Self-Finance Women' && isset($_POST['sfw-department']) && !empty($_POST['sfw-department'])) {
        $department = $_POST['sfw-department'];
    }

    // Handle image upload
    $image = $employee['image']; // Default to current image if not uploaded
    // if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
    //     // Ensure the directory exists
    //     $targetDir = '../uploads/' . $stream . '/' . $department . '/';
    //     if (!is_dir($targetDir)) {
    //         mkdir($targetDir, 0777, true);
    //     }

    //     $imageName = basename($_FILES['image']['name']);
    //     $targetFile = $targetDir . $imageName;

    //     // Move the uploaded image to the appropriate directory
    //     if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
    //         $image = 'uploads/' . $stream . '/' . $department . '/' . $imageName;
    //     } else {
    //         echo "Image upload failed!";
    //     }
    // }

    // Prepare and execute the SQL query
    $sql = "UPDATE `registration` SET 
            `prefix`='$prefix', 
            `name`='$name', 
            `qualification`='$qualification', 
            `stream`='$stream', 
            `department`='$department', 
            `category`='$category', 
            `designation`='$designation', 
            `dob`='$dob', 
            `mobile`='$mobile', 
            `address`='$address', 
            `email`='$email', 
            `image`='$image' 
            WHERE `empid`='$empid'";

    if (mysqli_query($conn, $sql)) {
        echo '<script>
                        location.replace("dashboard.php");

                alert("Record updated successfully!");
              </script>';
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
    }
    ?>
</body>
</html>
