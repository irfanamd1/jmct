function getStream() {
    let stream = document.getElementById("stream").value;
    let aided = document.getElementById("aided");
    let sfm = document.getElementById("sfm");
    let sfw = document.getElementById("sfw")
    console.log(stream);

    if (stream === 'Aided') {
        aided.style.display = 'block';
        sfm.style.display = 'none';
        sfw.style.display = 'none';
    } else if (stream === 'Self-Finance Men') {
        sfm.style.display = 'block';
        aided.style.display = 'none';
        sfw.style.display = 'none';
    } else if (stream === 'Self-Finance Women') {
        sfw.style.display = 'block';
        aided.style.display = 'none';
        sfm.style.display = 'none';
    }
}
