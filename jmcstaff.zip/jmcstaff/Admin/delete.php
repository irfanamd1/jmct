<?php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'jmc_staff_assoc';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// $db = mysqli_select_db($connection,"dbcrud");
$empid = $_GET['empid'];


$sql = "delete from registration where empid = '$empid'";


if(mysqli_query($conn,$sql))
           {

            echo '<script>
            alert("Record Deleted");
                        location.replace("dashboard.php");

        
             </script>';  
           }
           else
           {
           echo "Some thing Error" . $connection->error;

           }

?>