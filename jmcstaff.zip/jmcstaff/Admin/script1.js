function getStream() {
    let stream = document.getElementById("stream").value;
    let aided = document.getElementById("aided");
    let sfm = document.getElementById("sfm");
    let sfw = document.getElementById("sfw")
    console.log(stream);

    if (stream === 'Aided') {
        aided.style.display = 'block';
        sfm.style.display = 'none';
        sfw.style.display = 'none';
    } else if (stream === 'Self-Finance Men') {
        sfm.style.display = 'block';
        aided.style.display = 'none';
        sfw.style.display = 'none';
    } else if (stream === 'Self-Finance Women') {
        sfw.style.display = 'block';
        aided.style.display = 'none';
        sfm.style.display = 'none';
    }
}

/*function getCategory() {
    let category = document.getElementById("category").value;
    let teaching = document.getElementById("teaching")
    let nonTeaching = document.getElementById("non-teaching")

    if (category === 'Teaching') {
        teaching.style.display = 'block';
        nonTeaching.style.display = 'none';
    } else if (category === 'Non-Teaching') {
        nonTeaching.style.display = 'block';
        teaching.style.display = 'none';
    }
}*/


// function getEmail() {
//     let category = document.getElementById("category").value;
//     let email = document.getElementById("emaill");
//     let teachingemail = document.getElementById("teachingemaill");
//     let nonteachingemail = document.getElementById("nonteachingemaill");

//     if (category === 'Teaching') {
//         email.style.display = 'none';
//         teachingemail.style.display = 'block';
//         nonteachingemail.style.display = 'none';
//     } else if (category === 'Non-Teaching') {
//         email.style.display = 'none';
//         teachingemail.style.display = 'none';
//         nonteachingemail.style.display = 'block';
//     }
// }



const form = document.getElementById("form");
const prefix = document.getElementById("prefix");
const names = document.getElementById("name");
const qualification = document.getElementById("qualification");
const stream = document.getElementById("stream");
const aided = document.getElementById("aided-department");
const sfm = document.getElementById("sfm-department");
const sfw = document.getElementById("sfw-department");
const category = document.getElementById("category");
const designation = document.getElementById("designation");
const empid = document.getElementById("empid");
const date = document.getElementById("date");
const address = document.getElementById("address");
const mobile = document.getElementById("mobile");
const email = document.getElementById("email");
let teachingemail = document.getElementById("teachingemail");
let nonteachingemail = document.getElementById("nonteachingemail");
const image = document.getElementById("image");
// const check = document.getElementById("check");

    const imageBox = document.getElementById('imageBox');

    image.addEventListener('change', (event) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          imageBox.innerHTML = `<img src="${e.target.result}" alt="Selected Image">`;
        };
        reader.readAsDataURL(file);
      } else {
        imageBox.innerHTML = '<p>No image selected</p>';
      }
    });


form.addEventListener('submit', (event)=>{
    
    validateForm();
    console.log(isFormValid());
    if(isFormValid()==true){
        form.submit();
     }else {
         event.preventDefault();
     }

});

// form.addEventListener('change', function(){
    
//     validateForm();

// });

function isFormValid(){
    const inputContainers = form.querySelectorAll('.form-input');
    let result = true;
    inputContainers.forEach((container)=>{
        if(container.classList.contains('error')){
            result = false;
        }
    });
    return result;
}

function validateForm() {

    // if(prefix.value.trim() === '' ){
    //     setError(prefix, 'Prefix cannot be empty');
    // }else {
    //     setSuccess(prefix);
    // }

    // if(names.value.trim() === '' ){
    //     setError(names, 'Name cannot be empty');
    // }else if(isNamesValid(names.value)){
    //     setSuccess(names);
    // }else{
    //     setError(names, 'Only Alphabets are allowed');
    // }

    // if(qualification.value.trim() === '' ){
    //     setError(qualification, 'Qualification cannot be empty');
    // }else if(isQualificationValid(qualification.value)){
    //     setSuccess(qualification);
    // }else{
    //     setError(qualification, 'Only Alphabets Allowed');
    // }

    // if(stream.value.trim() === '' ){
    //     setError(stream, 'Stream cannot be empty');
    // }else {
    //     setSuccess(stream);

    //     if (stream.value === 'Aided' && aided.value.trim() === '') {
    //         setError(aided, 'Department cannot be empty');
    //     } else if (stream.value === 'Self-Finance Men' && sfm.value.trim() === '') {
    //         setError(sfm, 'Department cannot be empty');
    //     } else if (stream.value === 'Self-Finance Women' && sfw.value.trim() === '') {
    //         setError(sfw, 'Department cannot be empty');
    //     } else {
    //         setSuccess(aided);
    //         setSuccess(sfm);
    //         setSuccess(sfw);
    //     }
    // }

    // if(category.value.trim() === '' ){
    //     setError(category, 'Category cannot be empty');
    // }else {
    //     setSuccess(category);

        
    //     if (category.value === 'Teaching') {
    //         if (teachingemail.value.trim() === '') {
    //             setError(teachingemail, 'E-Mail cannot be empty');
    //         } else if (!isEmailValid(teachingemail.value)) {
    //             setError(teachingemail, 'Only Institutional-Id is allowed');
    //         } else {
    //             setSuccess(teachingemail);
    //         }
    //     } else if (category.value === 'Non-Teaching') {
    //         if (nonteachingemail.value.trim() === '') {
    //             setSuccess(nonteachingemail);
    //         } else if (!isEmailValidd(nonteachingemail.value)) {
    //             setError(nonteachingemail, 'Enter a valid Email Id');
    //         } else {
    //             setSuccess(nonteachingemail);
    //         }
    //     }
    // }

	
	// if(designation.value.trim() === '' ){
    //     setError(designation, 'Designation cannot be empty');
    // }else {
    //     setSuccess(designation);
    // }

    // if(empid.value.trim() === '' ){
    //     setError(empid, 'Employee-Id cannot be empty');
    // }else {
    //     setSuccess(empid);
    // }

    // if(date.value.trim() === '' ){
    //     setError(date, 'Date of Birth cannot be empty');
    // } else if(isDateValid(date.value)){
    //     setSuccess(date);
    // }else{
    //     setError(date, 'DD-MM-YYYY format is allowed');
    // }

    // if(address.value.trim() === '' ){
    //     setError(address, 'Address cannot be empty');
    // }else {
    //     setSuccess(address);
    // }

    // if(mobile.value.trim() === '' ){
    //     setError(mobile, 'Mobile Number cannot be empty');
    // }else if(isMobileValid(mobile.value)){
    //     setSuccess(mobile);
    // }else{
    //     setError(mobile, 'Only 10 digit numbers are allowed');
    // }

    // if(email.value.trim() === '' ){
    //     setError(email, 'E-Mail cannot be empty');
    // }else if(isEmailValid(email.value)){
    //     setSuccess(email);
    // }else{
    //     setError(email, 'Only Institutional-Id is allowed');
    // }

    if (image.files.length === 0) {
        // setError(image, 'Choose a latest passport size photo with jpg format');
        setSuccess(image);
    } else {
        const file = image.files[0];
        const validTypes = ['image/jpeg', 'image/jpg'];
        const maxSize = 100 * 1024;

        if (!validTypes.includes(file.type)) {
            setError(image, 'Invalid file type. Please upload a .jpg file.');
        } else if (file.size > maxSize) {
            setError(image, 'Image size must be less than 100 KB.');
            console.log(file.size);
        } else {
            setSuccess(image);
        }
    }

    // if (!check.checked) {
    //     setError(check, 'Please check the box above before submitting');
    // } else {
    //     setSuccess(check);
    // }

}



function setError(element, errorMessage) {
    const parent = element.parentElement;
    if(parent.classList.contains('success')){
        parent.classList.remove('success');
    }
    parent.classList.add('error');
    const small = parent.querySelector('small');
    small.textContent = errorMessage;
}

function setSuccess(element){
    const parent = element.parentElement;
    if(parent.classList.contains('error')){
        parent.classList.remove('error');
    }
    parent.classList.add('success');
}

/*function emailFun() {
	if(email.value.length == 1) {
				email.value = email.value + '@jmc.edu';   
						email.value.setSelectionRange(0, 0);

	}
}

function cursor(val) {
	if(email.value.length == 0) {
				email.value = val + '@jmc.edu';   
					val.setSelectionRange(0, 0);

	}
}

function cursor(input) {
	setTimeout(()=>{
		const defaultValue=input.value;
		input.value="";
			input.value=default.value;
		input.setSelectionRange(0, 0);
	},0);
					
				
	
}*/


// let appended = false; // Flag to ensure '@gmail.com' is appended only once

// teachingemail.addEventListener('input', () => {
//   const value = teachingemail.value;

//   // Check if we should append '@gmail.com'
//   if (!appended && value.length == 1 && !value.includes('@')) {
//     teachingemail.value = value + '@jmc.edu';
//     appended = true;
//     teachingemail.setSelectionRange(1, 1);
// 	// Mark as appended
//   }

//   // Allow further typing after '@gmail.com' has been appended
//   if (appended) {
//     const parts = value.split('@jmc.edu');
//     teachingemail.value = parts[0] + '@jmc.edu' + (parts[1] || '');
//   }

//   // Ensure cursor stays at the beginning
// });



function isNamesValid(names) {
	return /^[A-Za-z ]+$/.test(names);
}

function isQualificationValid(qualification) {
	return /^[A-Za-z,. ]+$/.test(qualification);
}

function isMobileValid(mobile) {
	return /^([0-9]{10})+$/.test(mobile);
}

function isDateValid(date) {
    return /^([0-9-]{10})$/.test(date);
}

function isEmailValid(teachingemail) {
    return /^[a-zA-Z0-9._%+-,]+@jmc\.edu$/.test(teachingemail);
}

function isEmailValidd(nonteachingemail) {
    return /^[a-zA-Z0-9._%+-,]+@[a-z]{5}\.[a-z]{3}$/.test(nonteachingemail);
}

// const backButton = document.getElementById('backButton');
// const submitButton = document.getElementById('submitButton');

//     // Initial form data
//     const initialFormData = new FormData(form);

//     // Function to check if the form has changed
//     function hasFormChanged() {
//       const currentFormData = new FormData(form);
//       for (const [key, value] of initialFormData.entries()) {
//         if (currentFormData.get(key) !== value) {
//           return true; // A change is detected
//         }
//       }
//       return false; // No changes detected
//     }

//     // Event listener for input changes
//     form.addEventListener('input', () => {
//       if (hasFormChanged()) {
//         backButton.classList.add('hidden');
//         submitButton.classList.remove('hidden');
//       } else {
//         backButton.classList.remove('hidden');
//         submitButton.classList.add('hidden');
//       }
//     });