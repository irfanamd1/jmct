<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="shortcut icon" href="../jmc.png" type="image/x-icon">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" /></head>
<body>
    <div class="container">
        <div class="header-image">
            <img src="../jmc_logos.jpg" alt="">
        </div>
        <h2>Login</h2>
        <form id="loginForm">
            <div style="margin-top: 20px;" class="form-input">
                <input type="text" name="" id="email" placeholder="Username">
            </div>
            <div class="form-input">
                <input type="password" name="" id="password" placeholder="Password">
                <i class="fa-solid fa-eye toggle-icon" id="togglePassword"></i>
            </div>
            <div class="form-input">
                <button type="submit">Submit</button>
            </div>
            <!-- <div class="reg">
                <a href="../index.php">Back to Registration</a>
            </div> -->
            <div id="message" style="text-align: center"></div>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>