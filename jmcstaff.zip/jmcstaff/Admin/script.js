const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('password');

togglePassword.addEventListener('click', function () {
    // Toggle the type of the input field
    const type = passwordInput.type === 'password' ? 'text' : 'password';
    passwordInput.type = type;

    // Toggle the icon (show/hide)
    this.classList.toggle('fa-eye');
    this.classList.toggle('fa-eye-slash');
});


    const users = [
        { email: '123', password: '123', token: 'token1' },
      ];
  
      document.getElementById('loginForm').addEventListener('submit', (event) => {
        event.preventDefault();
  
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
  
        const user = users.find((u) => u.email === email && u.password === password);
  
        const messageDiv = document.getElementById('message');
        if (user) {
          localStorage.setItem('authToken', user.token);
  
          messageDiv.textContent = 'Login Successful! Redirecting...';
          messageDiv.style.color = 'green';
  
          setTimeout(() => {
            window.location.href = 'dashboard.php';
          }, 1000);
        } else {
          messageDiv.textContent = 'Please Enter Valid Username or Password!';
          messageDiv.style.color = 'red';
        }
      });