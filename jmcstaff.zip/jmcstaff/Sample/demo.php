<?php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'jmc_staff_assoc';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stream = $_GET['stream'] ?? '';
$department = $_GET['department'] ?? '';
$category = $_GET['category'] ?? '';
$employee_id = $_GET['empid'] ?? '';

// Base query
$query = "SELECT * FROM registration WHERE 1=1";

// Prepare and bind parameters dynamically
if ($stream) {
    $query .= " AND stream = ?";
}
if ($department) {
    $query .= " AND department = ?";
}
if ($category) {
    $query .= " AND category = ?";
}
if ($employee_id) {
    $query .= " AND empid = ?";
}

// Prepare statement
$stmt = $conn->prepare($query);

// Dynamically bind parameters based on the filters
$bindParams = [];
$types = ''; // This will hold the parameter types for bind_param

if ($stream) {
    $bindParams[] = $stream;
    $types .= 's'; // 's' for string
}
if ($department) {
    $bindParams[] = $department;
    $types .= 's';
}
if ($category) {
    $bindParams[] = $category;
    $types .= 's';
}
if ($employee_id) {
    $bindParams[] = $employee_id;
    $types .= 's';
}

// Bind the parameters
if (!empty($bindParams)) {
    $stmt->bind_param($types, ...$bindParams);
}

// Execute query
$stmt->execute();

// Get the result
$result = $stmt->get_result();
$employees = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="shortcut icon" href="../jmc.png" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="header">
        <form id="form" action="" method="GET">
            <div class="content">
                <select name="stream" id="stream" onchange="this.form.submit()">
                    <option value="">Select Stream</option>
                    <option value="Aided" <?= $stream == 'Aided' ? 'selected' : '' ?>>Aided</option>
                    <option value="Self-Finance Men" <?= $stream == 'Self-Finance Men' ? 'selected' : '' ?>>Self-Finance
                        Men</option>
                    <option value="Self-Finance Women" <?= $stream == 'Self-Finance Women' ? 'selected' : '' ?>>
                        Self-Finance Women</option>
                </select>
            </div>
            <div class="content">
                <select name="department" id="department" onchange="this.form.submit()">
                    <option value="">Department</option>
                    <option value="Arabic" <?= $department == 'Arabic' ? 'selected' : '' ?>>Arabic</option>
                    <option value="Biotechnology" <?= $department == 'Biotechnology' ? 'selected' : '' ?>>Biotechnology
                    </option>
                    <option value="Botany" <?= $department == 'Botany' ? 'selected' : '' ?>>Botany
                    </option>
                    <option value="Business Administration" <?= $department == 'Business Administration' ? 'selected' : '' ?>>Business Administration</option>
                    <option value="Chemistry" <?= $department == 'Chemistry' ? 'selected' : '' ?>>Chemistry</option>
                    <option value="Commerce" <?= $department == 'Commerce' ? 'selected' : '' ?>>Commerce</option>
                    <option value="Computer Science" <?= $department == 'Computer Science' ? 'selected' : '' ?>>
                        Computer Science</option>
                    <option value="Computer Science & IT" <?= $department == 'Computer Science & IT' ? 'selected' : '' ?>>
                        Computer Science & IT</option>
                    <option value="Computer Applications" <?= $department == 'Computer Applications' ? 'selected' : '' ?>>
                        Computer Applications</option>
                    <option value="Economics" <?= $department == 'Economics' ? 'selected' : '' ?>>Economics</option>
                    <option value="English" <?= $department == 'English' ? 'selected' : '' ?>>English</option>
                    <option value="Fashion Technology & Costume Designing" <?= $department == 'Fashion Technology & Costume Designing' ? 'selected' : '' ?>>Fashion Technology & Costume Designing</option>
                    <option value="English" <?= $department == 'English' ? 'selected' : '' ?>>English</option>
                    <option value="French">French</option>/
                    <option value="Hindi" <?= $department == 'Hindi' ? 'selected' : '' ?>>Hindi</option>
                    <option value="History" <?= $department == 'History' ? 'selected' : '' ?>>History</option>
                    <option value="Hotel Management" <?= $department == 'Hotel Management' ? 'selected' : '' ?>>Hotel
                        Management</option>
                    <option value="Library" <?= $department == 'Library' ? 'selected' : '' ?>>Library</option>
                    <option value="Mathematics" <?= $department == 'Mathematics' ? 'selected' : '' ?>>Mathematics</option>
                    <option value="Management Studies" <?= $department == 'Management Studies' ? 'selected' : '' ?>>
                        Management Studies</option>
                    <option value="Microbiology" <?= $department == 'Microbiology' ? 'selected' : '' ?>>Microbiology
                    </option>
                    <option value="Nutrition & Dietetics" <?= $department == 'Nutrition & Dietetics' ? 'selected' : '' ?>>
                        Nutrition & Dietetics</option>
                    <option value="Physical Education" <?= $department == 'Physical Education' ? 'selected' : '' ?>>
                        Physical Education</option>
                    <option value="Physics" <?= $department == 'Physics' ? 'selected' : '' ?>>Physics</option>
                    <option value="Social Work" <?= $department == 'Social Work' ? 'selected' : '' ?>>Social Work</option>
                    <option value="Tamil" <?= $department == 'Tamil' ? 'selected' : '' ?>>Tamil</option>
                    <option value="Urdu" <?= $department == 'Urdu' ? 'selected' : '' ?>>Urdu</option>
                    <option value="Visual Communication" <?= $department == 'Visual Communication' ? 'selected' : '' ?>>
                        Visual Communication</option>
                    <option value="Zoology" <?= $department == 'Zoology' ? 'selected' : '' ?>>Zoology</option>
                </select>

            </div>
            <div class="content">
                <select name="category" id="category" onchange="this.form.submit()">
                    <option value="">Category</option>
                    <option value="Teaching" <?= $category == 'Teaching' ? 'selected' : '' ?>>Teaching</option>
                    <option value="Non-Teaching" <?= $category == 'Non-Teaching' ? 'selected' : '' ?>>Non-Teaching</option>
                </select>
            </div>
            <div class="content" style="position: relative;">
                <input  type="text" name="empid" id="empid" placeholder="Employee Id">
                <button type="submit" id="search" style="position: absolute; right: 0px; border: 1px solid black;">Search</button>
            </div>
            <div class="content" style="margin-left: 60px;">
                <button type="submit" id="logout" style=" background-color: #DCCE29; color: black;border: 1px solid white ">Logout</button>
            </div>
        </form>
    </div>
    <div class="container">



        <?php if (empty($employees)): ?>
            <div class="no-results">No results found.</div>
        <?php else: ?>
            <?php foreach ($employees as $employee): ?>
                <div class="card">
                    <div class="card-image">
                        <img src='<?= htmlspecialchars('../' . $employee['image']) ?>' alt="image">
                    </div>
                    <div class="card-content">
                        <h4 class="card-title">
                            <?= htmlspecialchars($employee['prefix']) . htmlspecialchars($employee['name']) ?></h4>
                        <h6 class="card-subtitle"><strong>E.Id:</strong><?= htmlspecialchars($employee['empid']) // echo "$empid"; ?></h6>
                        <ul class="card-details" style="margin-bottom: 40px;">
                            <li><?= htmlspecialchars($employee['qualification']) ?></li>
                            <li><?= htmlspecialchars($employee['designation']) ?></li>
                            <li><?= htmlspecialchars($employee['department']) ?></li>
                            <li><?= htmlspecialchars($employee['address']) ?></li>
                            <li><?= htmlspecialchars($employee['mobile']) ?></li>
                            <li><?= htmlspecialchars($employee['email'])?></li>
                            
                        </ul>
                        <div class="card-buttons">
                            <a class="btn delete-btn" href='delete.php?empid=<?php echo $employee['empid'] ?>'>Delete</a>
                            <a class="btn update-btn" href='update.php?employee=<?= urlencode(json_encode($employee)) ?>'>Update</a>                        
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>


    <script>
    window.onload = function () {
      const token = localStorage.getItem('authToken');
      if (!token) {
        window.location.href = 'index.php';
      }
    };

    window.onpageshow = function (event) {
      if (event.persisted) {
        const token = localStorage.getItem('authToken');
        if (!token) {
          window.location.href = 'index.php';
        }
      }
    };
    document.getElementById('logout').addEventListener('click', () => {
      localStorage.removeItem('authToken');
      window.location.href = 'index.php'; 
    });
  </script>
</body>

</html>